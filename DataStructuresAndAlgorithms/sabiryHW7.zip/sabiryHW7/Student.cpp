/********************************************
* Student class definition file with methods
* and operator overloading for sorting by id
*
* Author: Yaseer Sabir
* Version: 5/4/2025
*********************************************/

#include "Student.h"
//default constructor
Student::Student() {
    firstName = "";
    lastName = "";
    id = 0;
}

//constructor with parameters
Student::Student(std::string fn, std::string ln, int i) {
    firstName = fn;
    lastName = ln;
    id = i;
}
//getters
std::string Student::getFirstName() const {
    return firstName;
}

std::string Student::getLastName() const {
    return lastName;
}

int Student::getId() const {
    return id;
}

//to compare by id
bool Student::operator<(const Student& other) const {
    return id < other.id;
}
